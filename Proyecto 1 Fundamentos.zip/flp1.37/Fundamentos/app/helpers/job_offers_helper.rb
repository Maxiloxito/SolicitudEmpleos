module JobOffersHelper
end
