class PagesController < ApplicationController
  def index
  end

end
