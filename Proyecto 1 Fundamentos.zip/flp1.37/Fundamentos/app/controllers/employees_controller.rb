class EmployeesController < ApplicationController
    def dashboard
    end
    
end
  